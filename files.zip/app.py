import os
import uuid
import json
import time
import feedparser
import trafilatura
import deepl
import requests
from datetime import datetime
from flask import Flask, render_template, jsonify, request, send_file
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from config import RSS_FEEDS, DEEPL_API_KEY, TARGET_LANGUAGE

app = Flask(__name__)
app.config["OUTPUT_DIR"] = os.path.join(os.path.dirname(__file__), "output")
os.makedirs(app.config["OUTPUT_DIR"], exist_ok=True)

# ─── Helpers ────────────────────────────────────────────────────────────────

def fetch_feed(source):
    """Parse one RSS feed and return list of article dicts."""
    try:
        feed = feedparser.parse(source["url"])
        articles = []
        for entry in feed.entries[:20]:  # limit to latest 20 per source
            articles.append({
                "id":      str(uuid.uuid4()),
                "source":  source["name"],
                "title":   entry.get("title", "No title"),
                "url":     entry.get("link", ""),
                "summary": entry.get("summary", ""),
                "date":    entry.get("published", ""),
            })
        return articles
    except Exception as e:
        print(f"[ERROR] {source['name']}: {e}")
        return []


def extract_full_text(url):
    """Download the page and extract clean article text."""
    try:
        downloaded = trafilatura.fetch_url(url)
        if downloaded:
            text = trafilatura.extract(downloaded, include_comments=False, include_tables=False)
            return text or ""
    except Exception as e:
        print(f"[EXTRACT ERROR] {url}: {e}")
    return ""


def translate_text(translator, text):
    """Translate text to Turkish using DeepL."""
    if not text or not text.strip():
        return ""
    try:
        result = translator.translate_text(text, target_lang=TARGET_LANGUAGE)
        return result.text
    except Exception as e:
        print(f"[TRANSLATE ERROR]: {e}")
        return text  # return original if translation fails


def build_docx(articles_data):
    """Build a formatted Word document from translated articles."""
    doc = Document()

    # ── Page margins ──
    for section in doc.sections:
        section.top_margin    = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin   = Inches(1.2)
        section.right_margin  = Inches(1.2)

    # ── Cover heading ──
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title_para.add_run("HAFTALIK HABER ÖZETİ")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6B)

    date_para = doc.add_paragraph()
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date_run = date_para.add_run(datetime.now().strftime("%d %B %Y"))
    date_run.font.size = Pt(11)
    date_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    doc.add_paragraph()  # spacer

    # ── Articles ──
    for i, art in enumerate(articles_data, 1):
        # Article number + source badge
        meta = doc.add_paragraph()
        source_run = meta.add_run(f"[{i}]  {art['source'].upper()}")
        source_run.bold = True
        source_run.font.size = Pt(9)
        source_run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

        # Translated title
        title_p = doc.add_paragraph()
        t_run = title_p.add_run(art.get("title_tr", art["title"]))
        t_run.bold = True
        t_run.font.size = Pt(14)
        t_run.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6B)

        # Original title (smaller, grey)
        orig_p = doc.add_paragraph()
        o_run = orig_p.add_run(f"Orijinal: {art['title']}")
        o_run.italic = True
        o_run.font.size = Pt(9)
        o_run.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)

        # Article body (translated)
        body_text = art.get("body_tr") or art.get("summary_tr") or ""
        if body_text:
            body_p = doc.add_paragraph(body_text)
            body_p.style.font.size = Pt(11)
            for run in body_p.runs:
                run.font.size = Pt(11)

        # Source URL
        url_p = doc.add_paragraph()
        url_run = url_p.add_run(f"Kaynak: {art['url']}")
        url_run.font.size = Pt(8)
        url_run.font.color.rgb = RGBColor(0x00, 0x70, 0xC0)

        # Divider
        div = doc.add_paragraph("─" * 80)
        div.runs[0].font.size = Pt(8)
        div.runs[0].font.color.rgb = RGBColor(0xCC, 0xCC, 0xCC)

    # ── Footer note ──
    footer_p = doc.add_paragraph()
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    f_run = footer_p.add_run(
        f"Bu belge otomatik olarak oluşturulmuştur • {datetime.now().strftime('%d.%m.%Y %H:%M')}"
    )
    f_run.font.size = Pt(8)
    f_run.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)

    # ── Save ──
    filename = f"haberler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    filepath = os.path.join(app.config["OUTPUT_DIR"], filename)
    doc.save(filepath)
    return filename, filepath


# ─── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", sources=[f["name"] for f in RSS_FEEDS])


@app.route("/api/fetch", methods=["POST"])
def api_fetch():
    """Fetch articles from all RSS feeds."""
    all_articles = []
    for source in RSS_FEEDS:
        articles = fetch_feed(source)
        all_articles.extend(articles)
    return jsonify({"articles": all_articles, "count": len(all_articles)})


@app.route("/api/translate", methods=["POST"])
def api_translate():
    """Translate selected articles and return a downloadable docx."""
    data = request.json
    selected = data.get("articles", [])  # list of article dicts

    if not selected:
        return jsonify({"error": "No articles selected"}), 400

    if DEEPL_API_KEY == "YOUR_DEEPL_API_KEY_HERE":
        return jsonify({"error": "Please set your DeepL API key in config.py"}), 400

    try:
        translator = deepl.Translator(DEEPL_API_KEY)
    except Exception as e:
        return jsonify({"error": f"DeepL init failed: {e}"}), 500

    results = []
    for art in selected:
        # Fetch full article body
        body = extract_full_text(art["url"]) if art.get("url") else ""
        if not body:
            body = art.get("summary", "")

        # Translate title
        title_tr = translate_text(translator, art["title"])

        # Translate body (or summary as fallback)
        body_tr = translate_text(translator, body) if body else ""
        summary_tr = translate_text(translator, art.get("summary", "")) if not body else ""

        results.append({
            **art,
            "title_tr":   title_tr,
            "body_tr":    body_tr,
            "summary_tr": summary_tr,
        })
        time.sleep(0.1)  # be polite to DeepL

    # Build Word document
    filename, filepath = build_docx(results)
    return jsonify({"filename": filename, "count": len(results)})


@app.route("/api/download/<filename>")
def api_download(filename):
    """Serve the generated docx file."""
    filepath = os.path.join(app.config["OUTPUT_DIR"], filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "File not found"}), 404
    return send_file(filepath, as_attachment=True, download_name=filename)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
